/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.network;

import Interface.Sign_in;
import Interface.Signin_signUP;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author Soha Ragay
 */
public class LibraryNetwork {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        // TODO code application logic here
        Scanner Cin = new Scanner(System.in); 
        Scanner CinInt = new Scanner(System.in); 
        Signin_signUP WelcomePage = new Signin_signUP();
        WelcomePage.show();
        //Sign_in SignIn = new Sign_in();
        //SignIn.show();
        String Name , Email , Gender , password;
        String BTitle , BCatagory , BAuther , BDescription,BReview,BStatues;
        String Brank;
        int choose = 0;
        
        System.out.println("1-    sign up ");
        System.out.println("2-    sign in ");
        System.out.print("Choose : ");
        choose = CinInt.nextInt();
        
        book Book = new book();
        Reader reader = new Reader();
        Readercontroller control= new Readercontroller();
        BookControl controlBook= new BookControl();

        if(choose == 1){
                System.out.print("Name : ");
                Name = Cin.nextLine();
                reader.SetName(Name);
                
                System.out.print("Email : ");
                Email = Cin.nextLine();
                reader.SetEmail(Email);
                
                System.out.print("Gender : ");
                Gender = Cin.nextLine();
                reader.SetGender(Gender);
                
                System.out.print("Password : ");
                password = Cin.nextLine();
                reader.SetPassword(password);
                
                control.SignUp(reader);
        }
        else if (choose == 2){
                System.out.print("Email : ");
                Email = Cin.nextLine();
                reader.SetEmail(Email);
                
                System.out.print("Password : ");
                password = Cin.nextLine();
                reader.SetPassword(password);
                
                System.out.println();
                Boolean flag = control.SignIn(reader); 
                if(flag == false){
                    return;
                }
        }
        //Cin.nextLine();
        int method = 0;
        while(true){ 
                    System.out.println();
                    System.out.println();
                    System.out.println("1-    Add Book");
                    System.out.println("2-    Search about book");
                    System.out.println("3-    Rate Book/Write Review");
                    System.out.println("4-    Mark Book as read/to read/currently reading");
                    System.out.println();
                    System.out.println();                    

                    method = CinInt.nextInt();
                   // Cin.nextLine();
                    if(method == 1){
                                //Cin.nextLine();
                            System.out.print("Title : ");
                            BTitle = Cin.nextLine();
                            Book.SetTitle(BTitle);

                            System.out.print("Catagory : ");
                            BCatagory = Cin.nextLine();
                            Book.SetGatagory(BCatagory);

                            System.out.print("Auther : ");
                            BAuther = Cin.nextLine();
                            Book.SetAuther(BAuther);
                            
                            System.out.print("Description : ");
                            BDescription = Cin.nextLine();
                            Book.SetDescription(BDescription);
                            
                            System.out.println("Mark Book as read/to read/currently reading ");
                            BStatues = Cin.nextLine();
                            Book.SetStatues(BDescription);
                            
                            System.out.print("Review : ");
                            BReview = Cin.nextLine();
                            Book.SetReview(BReview);
                            
                            System.out.print("Rank from 1 : 5  = ");
                            Brank = Cin.next();
                            Book.SetRank(Brank);

                            controlBook.AddBook(reader  , Book );
                            //controlBook.AddBook(reader, null);
                        }
                        else if(method == 2){
                            System.out.print("Title : ");
                            System.out.println();
                            BTitle = Cin.nextLine();
                            controlBook.Search(reader, BTitle);
                        }
                        else if(method == 3){
                            System.out.print("Title : ");
                            BTitle = Cin.nextLine();
                            Book.SetTitle(BTitle);
                            
                            System.out.print("New Review : ");
                            BReview = Cin.nextLine();
                            Book.SetReview(BReview);
                            
                            System.out.print("New Rank from 1 : 5  = ");
                            Brank = Cin.next();
                            controlBook.updateReview(reader, BTitle, BReview, Brank);
                            
                        }
                        else if(method == 4){
                            System.out.print("Title : ");
                            BTitle = Cin.nextLine();
                            Book.SetTitle(BTitle);
                            
                            System.out.println("read/to read/currently reading ");
                            System.out.print("You mark book as  : ");
                            BStatues = Cin.nextLine();
                            System.out.println();
                            controlBook.updateStatus(reader, BTitle,BStatues);
                        }

                    }
    
        }   
    }
