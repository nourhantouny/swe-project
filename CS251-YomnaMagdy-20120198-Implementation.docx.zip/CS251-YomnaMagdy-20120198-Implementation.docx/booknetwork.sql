-- phpMyAdmin SQL Dump
-- version 4.1.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2014 at 12:56 PM
-- Server version: 5.6.15-log
-- PHP Version: 5.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `booknetwork`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `auther` varchar(128) NOT NULL,
  `catagory` varchar(128) NOT NULL,
  `description` varchar(128) NOT NULL,
  `rank` bigint(5) NOT NULL,
  `review` varchar(128) NOT NULL,
  `status` varchar(128) NOT NULL,
  `ID` bigint(128) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `auther` (`auther`,`catagory`,`description`,`rank`,`review`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=110 ;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`auther`, `catagory`, `description`, `rank`, `review`, `status`, `ID`, `title`) VALUES
('soha', 'rom', '.jm/.,j', 2, '/.k,/lk.', '.mn', 1, 'soham,'),
('gs', 'sdxf', 'sgdx', 1, 'sgfsx', 'sgdx', 2, 'zfsdf'),
('ss', 'saf', 'ss', 3, 'ss', 'ss', 100, 'saa'),
('?Lfs.,z', 'sf/l,c', '/s,mz', 5, '/lsmfc', '', 103, 's;LF'),
('Mohamed Sadek', 'Social', 'hebta is 7 in lateni and it''s 7 steps in love', 5, 'my fav book', 'd', 105, 'Hebta');

-- --------------------------------------------------------

--
-- Table structure for table `reader`
--

CREATE TABLE IF NOT EXISTS `reader` (
  `email` varchar(128) NOT NULL,
  `readerName` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `gender` varchar(128) NOT NULL,
  UNIQUE KEY `email` (`email`),
  KEY `readerName` (`readerName`,`password`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reader`
--

INSERT INTO `reader` (`email`, `readerName`, `password`, `gender`) VALUES
('soha@yahoo', 'Soha', 'soha123', 'female'),
('Soha_fci@gmail.com', 'soha ragay', '123456789', 'Female');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
