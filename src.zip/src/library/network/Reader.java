/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.network;

/**
 *
 * @author Soha Ragay
 */

public class Reader {

    
    private String ReaderName;
    private String Email;
    private String Password;
    private String Gender;
    
    public void SetName(String name){
        ReaderName = name;
    }
    public String GetName(){
        return ReaderName;
    }
    public void SetEmail(String mail){
        Email = mail;
    }
    public String GetEmail(){
        return Email;
    }
    public void SetPassword(String Pass){
        Password = Pass;
    }
    public String GetPassword(){
        return Password;
    }
    public void SetGender(String Gend){
        Gender = Gend;
    }
    public String GetGender(){
        return Gender;
    }
}
