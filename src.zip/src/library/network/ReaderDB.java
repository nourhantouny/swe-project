/*
 * To change this license header, choose License Headers in Project Properties.
 * To change11 this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.network;

import java.sql.*;
import java.sql.PreparedStatement;

/**
 *
 * @author Soha Ragay
 */
public class ReaderDB {

    public Connection myCon;
    public Statement myStm;
    public ResultSet myResl;

    public ReaderDB() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            myCon = DriverManager.getConnection("jdbc:mysql://localhost/booknetwork", "root", "");
            myStm = myCon.createStatement();
        } catch (ClassNotFoundException | SQLException ex) {
            System.err.println("Error : " + ex);
        }
    }


    //Sign up
    public void insertDate(Reader r) throws SQLException, ClassNotFoundException {

        String name = r.GetName();
        String email = r.GetEmail();
        String password = r.GetPassword();
        String Gender = r.GetGender();
        String QUARY;
        QUARY = "SELECT email FROM reader";
        myResl = myStm.executeQuery(QUARY);
        if (myResl != null) {
            while (myResl.next()) {
                if (email.equals(myResl.getString(1))) {
                    System.out.println("Email isn't valid");
                } else {

                    String sql = "INSERT INTO reader"
                            + "(email, readerName, password, gender) "
                            + "VALUES (?,?,?,?)";

                    PreparedStatement preparedStatement = (PreparedStatement) myCon.prepareStatement(sql);
                    preparedStatement.setString(1, email);
                    preparedStatement.setString(2, name);
                    preparedStatement.setString(3, password);
                    preparedStatement.setString(4, Gender);
                    preparedStatement.executeUpdate();
                    System.out.println(" Account Created ");
                    break;
                }   
                return ;
            }
        }
        myCon.close();
    }

    //Sign in 
    public Boolean CheckDate(Reader r) throws SQLException, ClassNotFoundException {
        //Class.forName("com.mysql.jdbc.Driver");
        //myCon = DriverManager.getConnection("jdbc:mysql://localhost/booknetwork", "root", "");
        String password = r.GetPassword();
        String email = r.GetEmail();
        String QUARY = "SELECT email, password FROM reader where `email` = '"+r.GetEmail()+"'";
        myResl = myStm.executeQuery(QUARY);
        if (myResl != null) {
            while (myResl.next()) {
                if (email.equals(myResl.getString("email")) && password.equals(myResl.getString("password"))) {
                    return true;
                } else {
                    System.err.println("E-mail or Password is Incorrect");
                    return false;
                }
            }
        }
        myCon.close();
        return false;
    }
 
    public void insertBook(Reader r , book b) throws SQLException, ClassNotFoundException{
        
        String tite ="";
        tite = b.GetTitle();
        //System.out.println("Title = "+tite );
        String Auther = b.GetAuther();
        String Desc = b.GetDescription();
        String Review = b.GetReview();
        String Stat = b.GetStatues();
        String catagory = b.GetCatagory();
        String rank = b.GetRank();
        int id= b.GetId();
        String QUARY;
        QUARY = "SELECT * FROM book where 1";
        myResl = myStm.executeQuery(QUARY);
        if (myResl != null) {
            while (myResl.next()) {
                
                    String sql  = "INSERT INTO book"
                                + "(auther, title, catagory, description, rank, review, status,ID) "
                                + "VALUES (?,?,?,?,?,?,?,?)";
                    PreparedStatement preparedStatement = (PreparedStatement) myCon.prepareStatement(sql);
                    preparedStatement.setString(1, Auther);
                    preparedStatement.setString(2, tite);
                    preparedStatement.setString(3, catagory);
                    preparedStatement.setString(4, Desc);
                    preparedStatement.setString(5, rank);
                    preparedStatement.setString(6, Review);
                    preparedStatement.setString(7, Stat);
                    preparedStatement.setInt(8, id);
                    preparedStatement.executeUpdate();
                    break;
            }
                    System.out.println(tite + " is added ");             

        }
        myCon.close();
    }
    //search_book
        public void SearchBook(Reader r , String TitleBook) throws SQLException, ClassNotFoundException{
            String QUARY = "SELECT * FROM book where `title` = '"+TitleBook+"'";
            myResl = myStm.executeQuery(QUARY);
            if (myResl != null) {
              while (myResl.next()) {
                System.out.println("             TitleBook : "+myResl.getString("title"));
                System.out.println("1-  Catagory : "+myResl.getString("catagory"));
                System.out.println("2-  Description : "+myResl.getString("description"));
                System.out.println("3-  Auther : "+myResl.getString("auther"));
                System.out.println("4-  Review : "+myResl.getString("review"));
                System.out.println("5-  Status : "+myResl.getString("status"));
                System.out.println("5-  Rank : "+myResl.getString("rank"));
                break;

              }
            }
        }
        public void updateStatus(Reader r , String Title,String Status ) throws SQLException, ClassNotFoundException{
              /* String Title = Book.GetTitle();
               String Status = Book.GetStatues();*/
                String QUARY = "SELECT status,ID FROM book where `title` = '"+Title+"'";
                myResl = myStm.executeQuery(QUARY);
                 if (myResl != null) {
                  while (myResl.next()){
                     int Id = myResl.getInt("ID");
                     String sql = "update book set status=? where ID=?";
                     PreparedStatement preparedStatement = (PreparedStatement) myCon.prepareStatement(sql);
                     preparedStatement.setString(1, Status);
                     preparedStatement.setInt(2, Id);
                     preparedStatement.executeUpdate();
                    }
                 }
                 else{System.out.println("Error");}
                 myCon.close();
        }
        
        public void updateReview_rank(Reader r , String Title,String review,String rank ) throws SQLException, ClassNotFoundException{
                String QUARY = "SELECT review,rank,ID FROM book where `title` = '"+Title+"'";
                myResl = myStm.executeQuery(QUARY);
                 if (myResl != null) {
                  while (myResl.next()){
                    int Id = myResl.getInt("ID");
                     String sql = "update book set review=? , rank=? where ID=?";
                        PreparedStatement preparedStatement = myCon.prepareStatement(sql);
                        preparedStatement.setString(1, review);
                        preparedStatement.setString(2, rank);
                        preparedStatement.setInt(3, Id);
                        int rowsAffected = preparedStatement.executeUpdate();
                    }
                  }
                  else{System.out.println("Error");}
                  myCon.close();
        }
        /*************************/
            //search_book
        public void SearchBookGUI(Reader r , book x) throws SQLException, ClassNotFoundException{
            String TitleBook= x.GetTitle();
            String QUARY = "SELECT * FROM book where `title` = '"+TitleBook+"'";
            myResl = myStm.executeQuery(QUARY);
            String Title, Catagory, Auther, Description, Review,Statues,rank;
            if (myResl != null) {
              while (myResl.next()) {
                Catagory = myResl.getString("catagory");
                x.SetGatagory(Catagory);
                Description=myResl.getString("description");
                x.SetDescription(Description);
                Auther = myResl.getString("auther");
                x.SetAuther(Auther);
                Review = myResl.getString("review");
                x.SetReview(Review);
                Statues = myResl.getString("status");
                x.SetStatues(Statues);
                rank = myResl.getString("rank");
                x.SetRank(rank);
                break;
              }
            }
        }
}
