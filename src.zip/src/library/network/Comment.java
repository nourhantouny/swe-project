/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.network;

/**
 *
 * @author Soha Ragay
 */
public class Comment {
   private String CommentContent;
   private String CommentDate;
   
    public void SetContent(String Content){
        CommentContent = Content;
    }
    public String GetContent(){
        return CommentContent;
    }
     
    public void SetDate(String Date){
        CommentDate = Date;
    }
    public String GetDate(){
        return CommentDate;
    }
    

}
