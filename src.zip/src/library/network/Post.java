/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.network;

/**
 *
 * @author Soha Ragay
 */
public class Post {
    private String postContant;
    private String postDate;
    
    public void SetContent(String Content){
        postContant = Content;
    }
    public String GetContent(){
        return postContant;
    }
     
    public void SetDate(String Date){
        postDate = Date;
    }
    public String GetDate(){
        return postDate;
    }
    
    public void AddComment(Post s , Comment c){}

}
