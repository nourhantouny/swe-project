/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.network;

/**
 *
 * @author Soha Ragay
 */
import java.sql.*;
public class Readercontroller {

    /**
     *
     */
    public Reader Ex;
    ReaderDB connect ;
    public void SignUp(Reader r) throws SQLException, ClassNotFoundException{
        connect =  new ReaderDB(); 
        connect.insertDate(r);
    }

    public Boolean SignIn(Reader r) throws SQLException, ClassNotFoundException{
        connect =  new ReaderDB(); 
        Boolean flag =connect.CheckDate(r);
        if (flag == false){
            return false;
        }  
     //  System.out.println("Flage controller = " + flag);
        return true;
    }
public void SetReader(Reader r){}
public void JoinGroup(Group g , Reader r){}
public void StringShareBook (book b, Reader r){}
public void AddFavCatagory (book b){}
public void Following (Reader r){}

}