/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.network;

/**
 *
 * @author Soha Ragay
 */
public class book {
    private String Title;
    private String Catagory;
    private String Auther;
    private String Description;
    private String Review;
    private String Statues;
    private String Rank;
    private int id;
    
    public book(){
        Title = "";
        Catagory= "";
        Auther = "";
        Description = "";
        Review= "";
        Statues= "";
        Rank= "";
        id = 0;
    }
    
     public void SetTitle(String title){
        Title = title;
    }
    public String GetTitle(){
        return Title;
    }
   
    
    public String GetCatagory(){
        return Catagory;
    }
    public void SetStatues(String Stat){
        Statues = Stat;
   }  
     public String GetStatues(){
        return Statues;
    }
    public void SetGatagory(String catagory){
        Catagory = catagory;
    }
    
    public String GetAuther(){
        return Auther;
    }
    public void SetAuther(String auther){
        Auther = auther;
    }
    
    public String GetDescription(){
        return Description;
    }
    public void SetDescription(String description){
        Description = description;
    }
    public String GetReview(){
        return Review;
    }
    public void SetReview(String review){
        Review = review;
    }
    
    public String GetRank(){
        return Rank;
    }
    public void SetRank(String rank){
        Rank = rank;
    }
     public int GetId(){
        return id;
    }
    public void SetId(int ID){
        id = ID;
    }
   
}
