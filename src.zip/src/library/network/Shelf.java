/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.network;

import java.util.ArrayList;

/**
 *
 * @author Soha Ragay
 */
public class Shelf {
    private String ShName;
    private String Catagory;
    
    public void SetShName(String name){
        ShName = name;
    }
    public String GetShName(){
        return ShName;
    }
    
    public String GetCatagory(){
        return Catagory;
    }
    public void SetGatagory(String catagory){
        Catagory = catagory;
    }
    
    
    public void UpdateBookList (ArrayList <book> books){}
    public void SortByTitle (ArrayList <book> books){}
    public void SearchByCatagory (ArrayList <book> books){}
    

    
}
