/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.network;

import java.util.Scanner;

/**
 *
 * @author Soha Ragay
 */
import java.sql.*;

public class BookControl {
    ReaderDB Connect;  
    
    public void Search(Reader r,String BookTitle) throws SQLException, ClassNotFoundException{
            Connect =  new ReaderDB();
            Connect.SearchBook(r, BookTitle);
    }
    public void AddBook(Reader r , book x) throws SQLException, ClassNotFoundException{
        Connect =  new ReaderDB();
        Connect.insertBook(r, x);
    }
    public void updateStatus(Reader r , String Title,String Status) throws SQLException, ClassNotFoundException{
        Connect =  new ReaderDB();
        Connect.updateStatus(r, Title, Status);
    }
    public void updateReview(Reader r , String TitleBook, String Review , String Rank ) throws SQLException, ClassNotFoundException{
        Connect =  new ReaderDB();
        Connect.updateReview_rank(r, TitleBook, Review ,Rank);
    
    }
     public void SearchBookGUI(Reader r , book x) throws SQLException, ClassNotFoundException{
      Connect =  new ReaderDB();
      Connect.SearchBookGUI(r, x);
     }
}
