/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.network;

/**
 *
 * @author Soha Ragay
 */
public class Like {
    public Reader r;
    public Post x;    
    public Boolean like;
    public int count;
     
    public void liked(int count , Post p){}
}
