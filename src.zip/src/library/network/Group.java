/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.network;

import java.util.ArrayList;

/**
 *
 * @author Soha Ragay
 */
public class Group {
    private String GrName;
    private String GrDescription;
    
    public String GetGrName(){
        return GrName;
    }
    public void SetGrName(String GrNme){
        GrName = GrNme;
    }
    
    public String GetGRDescription(){
        return GrDescription;
    }
    public void SetGRDescription(String Grdescription){
        GrDescription = Grdescription;
    }
    
    public void UpdateList(ArrayList <Reader> reader){}
    
    
}
